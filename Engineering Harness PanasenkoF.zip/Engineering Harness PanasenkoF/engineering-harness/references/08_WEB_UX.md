# 08. Web UI/UX — браузеры, SaaS, PWA, responsive

Применять только если текущий проект включает web-facing интерфейс. Часть правил требуется для desktop-web и mobile-web, но не для нативной оболочки без HTML. Первичные источники — в [SOURCES](SOURCES.md) с ключами [WAI], [WEB], [FL], [NNG].

## Information architecture и навигация

- URLs глубоких страниц должны быть адресуемыми и предсказуемыми, где это соответствует продукту. Browser Back/Forward, Refresh и открытие новой вкладки не должны сбрасывать несохранённый ввод без предупреждения. Не блокировать стандартные жесты браузера.
- Сделать понятную навигацию уровня продукта/объекта: где я, что могу сделать, что выбрано. Для глубоких структур breadcrumbs; для параллельных разделов tabs/sidebar; избегать самодельных «кнопок-ссылок» без href/семантики.
- Search/filter/sort: параметры, влияющие на shareable view, по возможности воспроизводимы в URL или сохранённой конфигурации; сброс фильтров явный, пустой результат отличается от отсутствия данных; возврат по истории сохраняет контекст.
- Использовать семантический HTML: landmarks, headings, `button` для действия, `a` для перехода, `label` для поля, реальные таблицы для табличных данных. ARIA дополняет, а не заменяет корректный HTML.

## Responsive не равно «всё уменьшить»

- Делать layout устойчивым к ширине окна, browser zoom, масштабу шрифта, длинным языкам и разной плотности контента. Mobile-first удобен как метод, но breakpoints выбираются по **сломавшемуся содержимому**, а не по именам телефонов.
- CSS Grid/Flexbox, minmax, fluid typography, relative units и media/container queries используются по потребности. Контейнерный layout адаптируется к **месту компонента**, а не только к всему viewport. Не завязываться на pixel-perfect позиции.
- Доступные действия не пропадают бесследно на узкой ширине. Обосновывать сжатие панелей, перенос действий в меню и reflow таблиц; данных с высокой плотностью не заменять нечитабельными карточками лишь ради «mobile».
- Проверять минимум 320px и типичные tablet/desktop/ultrawide (или заданные проектом размеры), короткую высоту, browser zoom 200% (при необходимости до 400%), длинные слова, RTL в поддерживаемых локалях и `prefers-reduced-motion` / `forced-colors` если поддерживаются.
- Изображения responsive (`srcset`, `sizes`, `picture`), lazy loading некритичных медиа; не загружать десктопный гигантский hero на медленной мобильной сети без необходимости.

## Формы и асинхронные состояния

- Отчётливые видимые label, required/optional, единицы измерения, пример формата; error **рядом с полем**, summary для длинной формы и программная связь через `aria-describedby`.
- Валидация вовремя: минимизировать ложные ошибки при печати; серверная валидация обязательна независимо от JS. Не очищать все поля после одной ошибки, не превращать disabled Submit в загадку.
- Не запрашивать повторно только что введённое, если можно безопасно переиспользовать; явно сообщать о save/draft/autosave/conflict и double-submit prevention; не обещать сохранение, если оно ещё идёт.
- При открытии dialog корректно поместить и вернуть фокус; Escape только когда отмена допустима, keyboard trap исключительно внутри настоящего модального диалога. Меню, combobox, autocomplete, tabs, grid соблюдать [WAI-ARIA APG](https://www.w3.org/WAI/ARIA/apg/patterns/) с проверенным keyboard interaction.

## Доступность: проверяемый контракт

- Как универсальная цель для веба — WCAG 2.2 AA по актуальной спецификации и правовым требованиям проекта. Различать AA и AAA: WCAG 2.2 SC 2.4.13 Focus Appearance — AAA; SC 2.4.11 Focus Not Obscured Minimum — AA; SC 2.5.7 Dragging Movements и 2.5.8 Target Size (Minimum) — AA.
- Наличие доступной подписи, фокуса, достаточного контраста, смысловой структуры, сообщений об ошибке, skip links/landmarks, accessible authentication без ненужной когнитивной задачи.
- 24×24 CSS px (SC 2.5.8 AA) — **минимум с исключениями**, не целевой универсальный размер всех кликабельных элементов; в touch-oriented приложениях практично выбирать больший touch target согласно UI системе. Не смешивать dp и CSS pixels.
- Веб-тесты: keyboard-only (Tab/Shift+Tab, стрелки где APG требует, Enter/Space/Escape); минимум один современный screen reader/browsers в scope; проверка видимости фокуса и 200% zoom/reflow; axe/Lighthouse лишь автоматическая часть, не сертификат WCAG.

## Скорость, стабильность, диагностика

- Для сайтов, где релевантен пользовательский web performance, контролировать Core Web Vitals в реальных данных: **LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1**, как ориентиры Google для «good» на 75-м перцентиле; перед релизом сверить действующие пороги и определить среду. На SPA задача может дополнительно требовать navigation/render latency, virtualized large lists.
- При асинхронных загрузках резервировать место для медиа/компонентов, чтобы не сдвигать текст; skeleton только если он соответствует состоянию, без нескончаемых «ложных загрузок».
- Не запускать Lighthouse/performance-gate для docs-only изменения; для performance-sensitive UI использовать reproducible baseline, low-end profile и RUM если разрешено (без утечки личных данных).

## Приёмка web UI

`Browser back + refresh; narrow+wide viewport; zoom+font scale; form invalid/error/submit/cancel; keyboard-only+focus; accessible names/state; empty/loading/offline; permissions if used; regression of affected routes; expected performance where measured.`

Источники: [WCAG 2.2](https://www.w3.org/TR/WCAG22/), [APG](https://www.w3.org/WAI/ARIA/apg/), [web.dev responsive](https://web.dev/learn/design/), [MDN responsive](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design), [Core Web Vitals](https://web.dev/articles/defining-core-web-vitals-thresholds).
