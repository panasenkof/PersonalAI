# 09. Desktop UI/UX — Windows, macOS, Linux, Electron, Tauri, desktop-web

Не сводить настольное приложение к увеличенному телефону. Контракт выбирается по **реальной ОС и используемому UI-стеку**. Для Electron/Tauri одновременно применять [web](08_WEB_UX.md), но не имитировать все свойства нативного окна в браузерной странице без необходимости.

## Общая организация рабочего пространства

- **Многооконность/многозадачность:** при уместном сценарии документ и справочник рядом, отдельный просмотр деталей, окно редактирования; не плодить ненужные окна по умолчанию. Состояние документа/selection/scroll/filter после переключения окна сохраняется.
- **Resize и дисплеи:** малое окно и большой/ultrawide monitor, fractional DPI 125%/150%/200%, перенос между мониторами с разным scaling, изменение темизации, системная high-contrast/dark; не обрезать диалоги и меню.
- **Информационная плотность:** desktop может вмещать master-detail, боковые панели, таблицы, command bar; не использовать бесконечный ряд гигантских мобильных карточек там, где профессионал работает с десятками объектов. Density имеет настройку или адаптацию только если польза подтверждена.
- **Ввод:** мышь (hover, контекстное меню, selection), клавиатура (Tab, arrows, Space/Enter, shortcuts), иногда touch/pen. Каждое важное действие имеет доступный альтернативный способ; hover-only action недопустим.
- **Drag and drop:** реализовать только при понятном drop target, видимом preview/feedback, возможности отмены и альтернативе через меню/кнопку/keyboard для доступности. Внешнее перетаскивание файлов — отдельное разрешение/источник.

## Windows: Microsoft Fluent / WinUI / Microsoft Learn

- Навигацию выбирать по структуре: top tabs для peers, navigation view/left pane для широкой структуры, breadcrumbs для глубины, master-detail для активного просмотра записей. Стандартный Back действует предсказуемо, временный dialog/selection mode не создаёт лишнюю историю.
- CommandBar, context menu, стандартные диалоги выбора файлов, сообщения, toast и возможность Undo там, где разумно; системная темизация и контрастность, масштаб шрифта, UI Automation/Narrator.
- Горячие клавиши там, где повышают эффективность, **видимая discoverability** (menu labels/tooltips); соблюдать стандартные Ctrl+C/V/Z/S/F, F2, Esc, Tab, не перехватывать их для сюрпризов; локализовать, если требуется. Не делать все команды keyboard-only или shortcut-only.
- Fluent 2 — система логической сетки, spacing, типографики и взаимодействия; не обязательная библиотека для любого Win32/Electron-проекта. Брать системные компоненты, если это снижает сложность и помогает доступности.

Основа: [Windows navigation basics](https://learn.microsoft.com/en-us/windows/apps/design/basics/navigation-basics), [Keyboard accelerators](https://learn.microsoft.com/en-us/windows/apps/develop/input/keyboard-accelerators), [Fluent 2 layout](https://fluent2.microsoft.design/layout), [Fluent 2 accessibility](https://fluent2.microsoft.design/accessibility).

## macOS: Apple HIG / AppKit / SwiftUI

- Главная роль menu bar: команды должны быть обнаружимы и сгруппированы (File/Edit/View/Window/Help по смыслу); menu items отражают состояния, disabled объясним, shortcuts стандартны и соответствуют назначению.
- Поддерживать свободное изменение окон, multiwindow, Full Screen, split view и управление окнами так, как это уместно для приложения. Не подменять стандартную рамку окна кастомной графикой без нужды.
- Toolbar/sidebar/inspector/selection соответствуют контексту. Пользователь может работать часами, поэтому ясная типографика, управляемая плотность, fast search и немодальные операции важнее громоздких переходов.
- Стандартные Command+C/V/Z/S/F, навигация клавиатурой и Full Keyboard Access, контекстные меню, VoiceOver, Reduce Motion/Increase Contrast. Не перехватывать стандартную клавишу без явной причины.

Основа: [Designing for macOS](https://developer.apple.com/design/human-interface-guidelines/designing-for-macos/), [Windows](https://developer.apple.com/design/human-interface-guidelines/windows), [Menus](https://developer.apple.com/design/human-interface-guidelines/menus), [Keyboards](https://developer.apple.com/design/human-interface-guidelines/keyboards/).

## Linux и кроссплатформа

- Проверить выбранную среду (GNOME/KDE/Qt/GTK), системные темы и порталы для file chooser/permissions, keyboard shortcuts, MIME association; не выдавать Windows и macOS поведение за стандарт Linux.
- Если единый UI framework обслуживает все платформы, сохранить **общую задачу и терминологию**, а не identical pixels, и решить где оправдан platform-native адаптер.
- Проверить keyboard navigation, High Contrast, screen reader (платформенный), Wayland/X11 только когда релевантно, возможный доступ без мыши, не блокировать данные при закрытии окна.

## Минимальная матрица desktop QA

| Сценарий | Что проверять |
|---|---|
| Старт/окно | normal/maximized, narrow/ultrawide, multi-monitor, scaling, minimize/restore |
| Ввод и команды | keyboard-only, shortcuts/menus, mouse context menu, search, select many, undo |
| Состояние | 2 открытых документа, dirty draft, close/cancel, crash-restart где применимо |
| Доступность | screen reader, focus order/visible, high contrast, enlarged text, reduced motion |
| Файлы/система | open/save picker, drag-drop альтернативой, permissions, association, export/print если есть |
| Надёжность | no data loss, command idempotency, migration/backup/recovery if affected |

Нельзя заявлять «проверено на desktop», если проверена лишь web-страница в одном Chromium; Electron/Tauri rendering и настоящие Win/macOS windowing проверяются отдельно.
