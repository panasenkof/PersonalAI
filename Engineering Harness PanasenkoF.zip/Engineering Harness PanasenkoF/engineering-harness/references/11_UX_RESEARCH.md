# 11. Исследование референсов и проверка качества решения

## Когда запускать

- **Обязательно по смыслу:** новая ключевая пользовательская задача/flow, крупный редизайн, платформа меняется, текущий UX провален в наблюдениях, выбор нового interaction pattern, опасная массовая операция, требования доступности и безопасность.
- **Не нужно повторять:** docs-only, trivial bugfix, установленный типовой паттерн с рабочим approved reference и не изменившимся contract. Отметить `existing reference` или `N/A: reason`.

## Протокол на один сценарий

1. `Problem`: кто, зачем, частота, среда (browser/desktop/mobile), права, тип данных, риски ошибки, доказанный дефект/вопрос.
2. `Existing`: снять текущие screens/videos, пользовательские жалобы, design tokens/component library, реальный код и тесты; составить список неизменяемых утверждённых ограничений.
3. `Sources`: подобрать обычно **2–4** сравнимых продукта (не сайты-портфолио), официальные platform guidelines и a11y. Зафиксировать точный URL, дату, версию/платформу, степень достоверности: `observed/tested`, `official guideline`, `marketing screenshot`, `hypothesis`.
4. `Compare`: работа с пустым/длинным/ошибочным состоянием, открытия/возвраты, клавиатура/мышь/touch, screen readers, undo, многоэкранность. Отделить обязательный платформенный контракт от эстетической идеи.
5. `Decide`: для каждой полезной практики **ADOPT / ADAPT / REJECT** + причина: эффективность, риск, сложность реализации, согласованность с текущим продуктом. Выбрать один проектный UX-contract, а не делать copycat.
6. `Prototype / implement`: сначала сценарий, иерархия, работающий переход, затем визуальные токены/компоненты; сравнить old/new на той же задаче; не подменять interactive behavior статическим screenshot.
7. `Verify`: happy path, error/cancel, keyboard navigation, a11y, layout at constraints, performance; проанализировать affected regressions, записать версии, фотографии/скриншоты без секретов и C1/C2.

## Карточка решения (для PR, документа или issue)

```
Scenario/persona & failure: ...
Platform + inputs + device/window constraints: ...
Current design & approved invariants: ...
Reference A/B/C: title | date | URL | evidence type | observed UX pattern
Decision: ADOPT/ADAPT/REJECT and why
Contract: start → actions → expected verified end state; errors/undo/a11y
Checks: positive/error/keyboard/visual/native where applicable; SHA/version
C1: PASS/FAIL/NOT RUN ...
C2: MATCH/PARTIAL/DEVIATION/NOT VERIFIED ...
```

## Критерии качества

- Reference соответствует **одной задаче и платформе**, а не просто красивой картинке.
- У решения есть измеримая цель: меньше ошибок, больше успешных завершений, меньше потерь контекста, лучше время task completion (если можно измерить); не обещать статистический эффект без исследования.
- Никаких скрытых подмен согласованных пользовательских решений, отсутствует переписывание чужих активов.
- Для сложного специализированного продукта — проверка с реальными экспертами или прозрачная отметка, что это проектная гипотеза.

Источники: [Nielsen Norman Group 10 heuristics](https://www.nngroup.com/articles/ten-usability-heuristics/), [NN/g Complex Applications](https://www.nngroup.com/articles/strategies-complex-application-design/), [Apple HIG](https://developer.apple.com/design/human-interface-guidelines/), [Material](https://m3.material.io/), [Fluent 2](https://fluent2.microsoft.design/), [WAI WCAG](https://www.w3.org/TR/WCAG22/).
