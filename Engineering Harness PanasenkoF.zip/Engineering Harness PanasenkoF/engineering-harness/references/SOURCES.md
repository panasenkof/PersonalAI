# SOURCES — первоисточники и происхождение (проверены/сверены 27 октября 2026)

В этом архиве **не просто копия чужого скилла**: правила синтезированы и адаптированы на основании опубликованных материалов и ранее утверждённых пользователем требований по процессу. Источники разделены на: «описанные авторами подходы», наблюдения по исходникам, решения владельца, собственные защитные уточнения. Ссылки на код желательно сохранять на конкретном коммите, а не изменяемом main.

## [UB] ub-mode / Robert C. Martin («Uncle Bob»)

- Снимок Git tree `57a8bdd28e45ed41900ace0bafa2ff76dd9ed70f`: [SKILL.md](https://github.com/unclebob/ub-mode/blob/57a8bdd28e45ed41900ace0bafa2ff76dd9ed70f/SKILL.md), [README](https://github.com/unclebob/ub-mode/blob/57a8bdd28e45ed41900ace0bafa2ff76dd9ed70f/README.md), [репозиторий](https://github.com/unclebob/ub-mode).
- Принято с адаптацией: `First Make it Work → Then Make it Right → Follow Practice`, domain/types/boundaries, TDD, smallest patch, attack premise, root cause, idempotency, separate writers, meaningful behavior tests, mutation/complexity/duplication by need, handoffs.
- **Отклонено как универсальное:** push прямо в main, всеобъемлющие логи, недоказанная «безопасность» worktree cleanup, обязательная установка/исполнение сторонних инструментов/порогов. Причины в `06_SECURITY.md`.
- Сопутствующие отдельные проекты: [crapper](https://github.com/unclebob/crapper), [dryer](https://github.com/unclebob/dryer), [mutator](https://github.com/unclebob/mutator), [uml-viewer](https://github.com/unclebob/uml-viewer). Их код и зависимости не подвергнуты полной независимой проверке безопасности.

## [OA] Официальные рекомендации OpenAI

- [Harness engineering: leveraging Codex in an agent-first world](https://openai.com/index/harness-engineering/), 11.02.2026: репозиторий как источник истины, legibility, наблюдаемое поведение приложений, малая карта вместо огромного AGENTS.md, границы архитектуры и периодическая чистка документации.
- [Rethinking skills and prompts for GPT-6 Astra](https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra), 11.09.2026: краткие описания скиллов, progressive disclosure, избегание дублей и механического чтения всех документов при каждом tiny edit; ясные границы и критерии завершения.
- [OpenAI Skills, API documentation](https://developers.openai.com/api/docs/guides/tools-skills): SKILL.md + supporting files, версионируемые бандлы, совместимость с открытым стандартом.
- [Iterating Development Workflows with Codex](https://developers.openai.com/cookbook/examples/codex/iterating-development-workflows-with-codex), 03.08.2026: AGENTS.md и планы — необязательные, адаптируемые конвенции; протокол уточнения, фазы, проверяемые выходы, минимум бюрократии.
- **Оговорка:** конкретная merge/approval модель экспериментального OpenAI-проекта **не** автоматически применима ко всем проектам. Здесь безопасность и полномочия владельца выше её скорости слияния.

## [GG] Google / Harness engineering

- [The Anatomy of Harness Engineering: How to Evaluate, Iterate, and Guard AI Coding Agents](https://developers.googleblog.com/the-anatomy-of-harness-engineering-how-to-evaluate-iterate-and-guard-ai-coding-agents/), 09.09.2026: проверяемые поведенческие assertions, понимание причин провалов, быстрые детерминированные eval и их дополнение общими end-to-end тестами; учёт недетерминизма.

## [H2] Google Research / Harness²

- [Исходный README — фиксированный commit](https://github.com/google-research/harness2/blob/1cfe254e8d25b15f37048c3730134686abe60335/README.md), [исходники core](https://github.com/google-research/harness2/tree/1cfe254e8d25b15f37048c3730134686abe60335/harness2/core), [статья v1](https://arxiv.org/html/2610.14224v1).
- Взято: baseline/KEEP_BASE, сравнительные контролируемые прогоны, условная память опыта, ограниченные бюджеты, фиксация улучшений/ухудшений. **Не утверждаем**, что результаты benchmark перенесутся на другой продукт; не переносим разрешения экспериментального sandbox и не разрешаем самостоятельно редактировать guardrails в production.
- Адаптация ранее оформлена пользователем в [PersAI Harness evidence design](https://github.com/panasenkof/PersonalAI/blob/16569f1a856902bb2406e92e82c252f7db42cd01/openspec/changes/harness-evidence-improvement/design.md).

## [AN] Anthropic

- [Effective harnesses for long-running agents](https://www.anthropic.com/research/effective-harnesses-for-long-running-agents), 26.11.2025: устойчивость через мелкие этапы, список проверяемых функций, git/progress handoff, честная проверка end-to-end, новый агент восстанавливает состояние по файлам, не догадкам.
- [Building effective agents](https://www.anthropic.com/research/building-effective-agents), 19.12.2024: проще orchestration там, где сложность не доказана; инструменты с ясными контрактами.

## [PA] Требования, утверждённые владельцем PersAI, перенесённые как общая инженерная практика

- [PR #133 (правило каждой реализации)](https://github.com/panasenkof/PersonalAI/pull/133), [docs/DEVELOPMENT_GATES.md (фиксированный commit)](https://github.com/panasenkof/PersonalAI/blob/16569f1a856902bb2406e92e82c252f7db42cd01/docs/DEVELOPMENT_GATES.md), [AGENTS.md](https://github.com/panasenkof/PersonalAI/blob/16569f1a856902bb2406e92e82c252f7db42cd01/AGENTS.md), [PLAN.md §6](https://github.com/panasenkof/PersonalAI/blob/16569f1a856902bb2406e92e82c252f7db42cd01/PLAN.md): A/B/C1/C2, один порядок приоритетов, актуальный код/CI, профильные планы, соответствие diff контракту, честные PASS/NOT RUN.
- [mobile-ui-ux SKILL](https://github.com/panasenkof/PersonalAI/blob/16569f1a856902bb2406e92e82c252f7db42cd01/skills/mobile-ui-ux/SKILL.md), [QUALITY_GATES](https://github.com/panasenkof/PersonalAI/blob/16569f1a856902bb2406e92e82c252f7db42cd01/skills/mobile-ui-ux/references/QUALITY_GATES.md): research реальных аналогов, Apple HIG как ориентир качества + платформенные Android механики, изменение только нужных экранов, доступность, стабильность и native evidence.
- [ANDROID_UI_TESTING](https://github.com/panasenkof/PersonalAI/blob/16569f1a856902bb2406e92e82c252f7db42cd01/docs/ANDROID_UI_TESTING.md): минимальный надёжный smoke, таргетированные проверки, не ослаблять тесты ради PASS, реальная сборка отдельно от browser.
- [Conversational harness](https://github.com/panasenkof/PersonalAI/blob/16569f1a856902bb2406e92e82c252f7db42cd01/openspec/changes/conversational-harness/design.md): итог состояния инструмента нельзя выдумывать, управление goal/context и отменой, единый каталог инструментов.
- Все даты и конкретные ссылки на PersAI служат **provenance**, а не приказом скопировать его структуру, NDA, SQLCipher, Nebula, Android-тесты, нумерацию или частные настройки в новый проект.

## [UI] Платформенные UX первоисточники

- [Apple Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/), включая [motion](https://developer.apple.com/design/human-interface-guidelines/motion).
- [Android Developers — accessibility](https://developer.android.com/guide/topics/ui/accessibility/apps), [keyboard/IME](https://developer.android.com/develop/ui/views/touch-and-input/keyboard-input/visibility), [adaptive UI](https://developer.android.com/develop/ui/compose/layouts/adaptive), [Material Design](https://m3.material.io/).
- [React Native accessibility](https://reactnative.dev/docs/accessibility), [Nielsen Norman Group chatbots design guidelines](https://www.nngroup.com/articles/ai-chatbots-design-guidelines/).

## [NNG] Nielsen Norman Group — универсальные UX и экспертные приложения

- [10 Usability Heuristics for User Interface Design](https://www.nngroup.com/articles/ten-usability-heuristics/), Jakob Nielsen, исходная публикация 1994, обновление/проверка 30.01.2024: visibility of status, real-world match, user control, consistency, error prevention, recognition over recall, efficiency, minimal design, error recovery, help. **Эвристики, не нормативный стандарт и не доказательство конкретного UX.**
- [UX Strategies for Complex-Application Design](https://www.nngroup.com/articles/strategies-complex-application-design/), 25.07.2025: экспертные домены, нелинейные workflows, адаптация исследований под реальную работу. Конкретные table/bulk acceptance правила — **наша инженерная адаптация**, а не дословная цитата NN/g.

## [WAI] W3C — доступность web как проверяемые критерии

- [WCAG 2.2](https://www.w3.org/TR/WCAG22/), [Quick Reference](https://www.w3.org/WAI/WCAG22/quickref/): нормативные success criteria, уровень AA/AAA нужно различать; WCAG 2.2 добавляет Focus Not Obscured (AA), Dragging Movements (AA), Target Size Minimum 24 CSS px с исключениями (AA), Accessible Authentication (AA), Focus Appearance (AAA).
- [WAI-ARIA Authoring Practices Guide](https://www.w3.org/WAI/ARIA/apg/), [Patterns](https://www.w3.org/WAI/ARIA/apg/patterns/), [Keyboard Interface](https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/), [Data grid](https://www.w3.org/WAI/ARIA/apg/patterns/grid/): рекомендации и примеры реализации сложных доступных widgets. **APG — guidance, не отдельный нормативный стандарт.** Семантический HTML прежде custom ARIA.

## [FL] Microsoft — Fluent 2 и Windows Desktop

- [Fluent 2 Layout](https://fluent2.microsoft.design/layout), multi-platform spacing, responsive grid, resize/reflow и информационная иерархия.
- [Fluent 2 Accessibility](https://fluent2.microsoft.design/accessibility), семантика, структурирование контента и focus/order в дизайне; библиотека компонентов не заменяет аудит.
- [Microsoft Learn: Windows navigation](https://learn.microsoft.com/en-us/windows/apps/design/basics/navigation-basics), выбор структуры navigation/top/left/tabs/breadcrumb/master-detail/Back.
- [Microsoft Learn: Keyboard accelerators](https://learn.microsoft.com/en-us/windows/apps/develop/input/keyboard-accelerators), стандартные shortcut, обнаруживаемость в menus/tooltips, keyboard-only работа и UIA.

## [APPLE-DESKTOP] Apple HIG — macOS и многооконность

- [Designing for macOS](https://developer.apple.com/design/human-interface-guidelines/designing-for-macos/), [Windows](https://developer.apple.com/design/human-interface-guidelines/windows), [Menus](https://developer.apple.com/design/human-interface-guidelines/menus), [Keyboards](https://developer.apple.com/design/human-interface-guidelines/keyboards/): menu bar, resizable windows, multiwindow, Full Keyboard Access, стандартные shortcuts и системные компоненты. Это **платформенные guidelines**, не требование внедрять AppKit в Electron.

## [WEB] web.dev / MDN — адаптивность и реальные метрики

- [web.dev Learn Responsive Design](https://web.dev/learn/design/), fluid layouts, media and container queries, typography, adaptable input, responsive images, а не перечень жёстких ширин телефонов.
- [MDN Responsive Design](https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design), метод mobile first, Flex/Grid, относительные единицы, реальное окно вместо фиксированной макетной ширины.
- [Core Web Vitals methodology](https://web.dev/articles/defining-core-web-vitals-thresholds), LCP 2.5s, INP 200ms, CLS 0.1 как good thresholds (75th percentile; проверить актуальность перед включением gate). Метрики применимы к web и требуют фактических измерений.

## [AS] Совместимый формат Agent Skills

- [OpenAI Skills](https://developers.openai.com/api/docs/guides/tools-skills); [Agent Skills specification](https://agentskills.io/specification). Копирование в конкретный каталог зависит от клиента и должно проверяться в его документации.

## Матрица трассируемости

| Сфера | Источники | Наши изменения |
| --- | --- | --- |
| Контракт, актуальный план, небольшие PR, C1/C2 | PA + OA + AN | не требовать глобальную плановую структуру там, где она не нужна |
| Типы, границы, TDD, root cause, идемпотентность, CRAP/Dryer/Mutator | UB + OA | профильные проверки вместо жёсткой установки, права ограничены |
| Подтверждение результата, CI и шага агента | PA + GG + AN | конкретный SHA; подтверждение эффекта в системе |
| Harness eval, baseline, отбор уроков и откат | H2 + GG + OA + PA | никакой автономной смены guardrails, holdout, полная стоимость |
| Контекст, source of truth, чистка устаревших правил | OA + AN + PA | короткий основной skill + references, отдельная история |
| Mobile UX, accessibility, полезные образцы | PA + UI | платформонезависимое ядро, адаптер UI только по необходимости |
| Web/desktop UX, эвристики, complex apps | NNG + WAI + FL + APPLE-DESKTOP + WEB | отдельные платформенные контракты, строгая keyboard/a11y проверка, изучение 2–4 аналогов |
| Безопасность стороннего skill | UB + PA + общие меры supply-chain | отвергнуть прямой push/cleanup/секретные логи |
